package com.programmingtask.xlstopdf;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.poi.ss.usermodel.PrintSetup;

import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class TransformationService {
    @Value("${INPUT_FOLDER}") private String inputFolderPath;
    @Value("${PROCESSED_FOLDER}") private String processedFolderPath;
    @Value("${OUTPUT_FOLDER}") private String outputFolderPath;
    @Value("${REPLACE_EXISTING}") private boolean replaceExisting;

    private static final Logger LOGGER = LoggerFactory.getLogger(TransformationService.class);

    ExcelFileHandler xls = new ExcelFileHandler();
    DataTransformer convert = new DataTransformer();

    @Autowired
	public void transformationProcess () {
        File inputFolder = new File(inputFolderPath);
        File processedFolder = new File(processedFolderPath);
        File outputFolder = new File(outputFolderPath); 
        
        try {
            File[] excelFiles = inputFolder.listFiles((dir, name) -> name.endsWith(".xls") || name.endsWith(".xlsx"));
            xls.initializeFolderEnv(inputFolderPath, processedFolderPath, outputFolderPath);
            int i = 0;
            do {
                File excelFile = excelFiles[i];
                LOGGER.info("Opening {}...", excelFile.getName());
                xls.openFile(excelFile);
                List<Sheet> sheets = xls.getSheets();
                for (Sheet sheet : sheets) {
                    PrintSetup printSetup = xls.getPrintSetup(sheet);
                    List<List<String>> data = xls.getSheetDataWithFilter(sheet);
                    xls.writeToExcel(excelFile, data, processedFolder);
                    String pdfFileName = excelFile.getName().replaceAll("\\.xlsx?$", ".pdf");
                    File pdfFile = new File(outputFolder, pdfFileName);    
                    if (!pdfFile.exists()){
                        convert.fileExtractor(excelFile, pdfFile, pdfFileName, data, printSetup);
                    } else {
                        if (!replaceExisting) {
                            LOGGER.info("Skipping {}: PDF file {} already exists.", excelFile.getName(), pdfFileName);
                        } else {
                            LOGGER.info("PDF File is already exists!\nDeleting old converted {} file in the output folder...", pdfFileName);
                            Files.delete(pdfFile.toPath());
                            convert.fileExtractor(excelFile, pdfFile, pdfFileName, data, printSetup);
                        }
                    }
                }
                xls.closeFile();
                i++;
            } while (excelFiles.length > i);
            LOGGER.info("================   E N D   O F   T R A N S F O R M A T I O N   P R O C E S S   =================");
        } catch (IOException e) {
            LOGGER.error("Input/output error during conversion: {}", e.getMessage());
        } 
    }
}