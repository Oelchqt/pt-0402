package com.programmingtask.xlstopdf;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import org.apache.poi.ss.usermodel.PrintSetup;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;

public class PDFGenerator {
    /** Generate PDF file from Transformed Excel Sheet Data
     * 
     * @param data All retrieved data from Excel file
     * @param pdfFile Specified PDF file to be generated
     * @param printSetup The printSetup that preserves layouts and formats from Excel file
     * @throws IOException If an I/O error occurs
     */
     public void generatePdf(List<List<String>> data, File pdfFile, PrintSetup printSetup) throws IOException {
        try (PdfWriter pdfWriter = new PdfWriter(new FileOutputStream(pdfFile));
             PdfDocument pdfDocument = new PdfDocument(pdfWriter);
             Document document = new Document(pdfDocument)) {

            if (printSetup.getLandscape()) {
                pdfDocument.setDefaultPageSize(pdfDocument.getDefaultPageSize().rotate());
            }

            document.setMargins(document.getTopMargin(), document.getRightMargin(), document.getBottomMargin(), document.getLeftMargin());
            
            int numOfColumns = data.get(0).size();
            float pageWidth = pdfDocument.getDefaultPageSize().getWidth() - document.getLeftMargin() - document.getRightMargin();
            float maxCellWidth = pageWidth/numOfColumns;
            Table table = new Table(numOfColumns);
            table.setWidth(pageWidth);

            for (List<String> rowData : data) {
                for (String cellData : rowData) {     
                    Cell pdfCell = new Cell();
                    pdfCell.setMaxWidth(maxCellWidth);
                    pdfCell.setFontSize(8f);
                    pdfCell.add(new Paragraph(cellData));
                    table.addCell(pdfCell);
                }
            }
            document.add(table);
        }
    }
}