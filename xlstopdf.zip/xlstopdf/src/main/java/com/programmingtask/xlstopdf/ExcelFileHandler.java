package com.programmingtask.xlstopdf;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.PrintSetup;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExcelFileHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(ExcelFileHandler.class);
    private Workbook workbook;
    private Sheet sheet;
    
    /** Opens an Excel file
     * 
     * @param excelFile The Excel file to open
     * @throws IOException If an I/O error occurs
     */
     public void openFile(File excelFile) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(excelFile);
        workbook = WorkbookFactory.create(fileInputStream);
    }

    /** Closes the workbook
     * 
     * @throws IOException If an I/O error occurs
     */
    public void closeFile() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    /** Retrieves the list of sheets from the workbook
     * 
     * @return A list of sheets in the workbook
     */
    public List<Sheet> getSheets() {
        List<Sheet> sheets = new ArrayList<>();
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            sheets.add(workbook.getSheetAt(i));
        }
        return sheets;
    }

    /** Retrieves print setup values from a sheet
     * 
     * 
     * @param sheet The sheet to get print setup from
     * @return Print setup object
     */
     public PrintSetup getPrintSetup(Sheet sheet) {
        return sheet.getPrintSetup();
    }

    /** Retrieves data from the sheet as a list of rows and columns
     * 
     * @param sheet The sheet to read data from
     * @return List of rows, where each row is a list of cell values
     * @throws IOException 
     */
    public List<List<String>> getSheetDataWithFilter(Sheet sheet) {
        List<List<String>> data = new ArrayList<>();
        List<String> headerList = new ArrayList<>();

        Row headerRow = sheet.getRow(0);
        Iterator<Row> rowIterator = sheet.rowIterator();
        Iterator<Cell> cellIterator = headerRow.cellIterator();
        
        while (cellIterator.hasNext()){
            Cell cell = cellIterator.next();
            String headerKey = cell.getStringCellValue();
            headerList.add(headerKey);
        }

        while (rowIterator.hasNext()){
            Row row = rowIterator.next();
            List<String> rowData = new ArrayList<>();
            for (int i = 0; headerList.size() > i; i++){
                Cell retrieveCell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                rowData.add(retrieveCell.getStringCellValue());
            }
            data.add(rowData);
        }
        
        if (headerList.contains("question") || headerList.contains("Answer")){
            LOGGER.info("Question/Answer column key(s) has been detected.");
            List<List<String>> filteredData = new ArrayList<>();
            for (List<String> row : data){
                if (!row.contains("")) {
                    filteredData.add(row);
                }
            }
            data = filteredData;
        } else {
            LOGGER.info("The excel file doesn't have Question/Answer column key(s).");
        }
         return data;
     }
    
    /** Initializing the environment of input and output folder paths
     * 
     * @param inputFolderPath path to Excel files
     * @param processedFolderPath path to Processed Excel files
     * @param outputFolderPath path to output (PDF) files
     */
     public void initializeFolderEnv(String inputFolderPath, String processedFolderPath, String outputFolderPath) {
        File inputFolder = new File(inputFolderPath);
        File processedFolder = new File(processedFolderPath);
        File outputFolder = new File(outputFolderPath);
        if (!inputFolder.exists() || !inputFolder.isDirectory()){
            LOGGER.error("Input folder not found");
            System.exit(0);
        } 
        
        LOGGER.info("Input folder does exists");
        LOGGER.info("Checking processed folder environment...");

        if (!processedFolder.exists()) {
            if(!processedFolder.mkdirs()){
                LOGGER.error("Processed folder not found");
                LOGGER.info("Processed folder is automatically created");
            } 
        } else {
            LOGGER.info("Processed Folder does exists");
        }

        LOGGER.info("Processed Folder does exists");
        LOGGER.info("Checking output folder environment...");
        
        if (!outputFolder.exists()) {
            if(!outputFolder.mkdirs()){
                LOGGER.error("Output folder not found");
                LOGGER.info("Output folder is automatically created");
            } 
        } else {
            LOGGER.info("Output Folder does exists");
        }

        LOGGER.info("Proceed to Data Transformation (XLS -> PDF)");
    }

    /** Write new excel file for every processed excel files
     * 
     * @param excelFile Excel files to be transformed
     * @param data Retrieved data per cell from Excel file
     * @param appFolderPath Default path for processed files
     * @param processedFolderPath Transferred path for processed files
     * @throws IOException If an I/O error occurs
     */
     public void writeToExcel(File excelFile, List<List<String>> data, File processedFolder) {
        List<String> sheetNames = new ArrayList<>();
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
            sheetNames.add(workbook.getSheetName(i));
        }
        
        int sheetCount = workbook.getNumberOfSheets();
        for (int i = 0; i < sheetCount; i++) {
            sheet = workbook.createSheet("Processed-" + workbook.getSheetName(i));
        }

        int rowNum = 0;
        for (List<String> rowData : data) {
            Row row = sheet.createRow(rowNum++);
            int colNum = 0;
            for (String cellData : rowData) {
                Cell cell = row.createCell(colNum++);
                cell.setCellValue(cellData);
            }
        }

        try {
            String processedFileName = "[P]-" + excelFile.getName();
            File processedFile = new File(processedFolder, processedFileName);
            FileOutputStream outputStream = new FileOutputStream(processedFile);

            workbook.write(outputStream);
            LOGGER.info("Processed file saved to {}", processedFile.getAbsolutePath());
        } catch (IOException e) {
            LOGGER.error("Input/output error during conversion: {}", e.getMessage());
            System.exit(0);
        }
    }
}