package com.programmingtask.xlstopdf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
* The XlstopdfApplication program implements an application that
* converts multiple Excel files in an input folder to PDF files in an output folder.
*
* @author Oelch James Balbares
* @version 1.0
* @since 2024-04-08
*/
@SpringBootApplication
public class XlstopdfApplication {
    /** Main method to start the application
     * 
	 * @param args Command line arguments
	 */    
     public static void main(String[] args) {
        SpringApplication.run(XlstopdfApplication.class, args);
    }
} 