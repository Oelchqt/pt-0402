package com.programmingtask.xlstopdf;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.apache.poi.ss.usermodel.PrintSetup;

public class DataTransformer {
    private static final Logger LOGGER = LoggerFactory.getLogger(DataTransformer.class);

    ExcelFileHandler xls = new ExcelFileHandler();
    PDFGenerator pdf = new PDFGenerator();

    /** Simplifies generatePDF method and Retrieving file names
     * 
     * @param excelFile Input file for transformation
     * @param pdfFile Transformed output from Excel File
     * @param pdfFileName Generated for retrieval
     * @param data Retrieved from Excel file
     * @param printSetup Preserving Print Setup properties
     */
    public void fileExtractor(File excelFile, File pdfFile, String pdfFileName, List<List<String>> data, PrintSetup printSetup){
        LOGGER.info("Generating {}...", pdfFileName);
        try {
            pdf.generatePdf(data, pdfFile, printSetup);
            LOGGER.info("File '{}' is successfully converted to {}.\n", excelFile.getName(), pdfFileName);
        } catch (IOException e) {
            LOGGER.error("Input/output error during conversion: {}", e.getMessage());
        }
    }
}